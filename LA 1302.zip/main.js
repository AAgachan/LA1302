let quizData = [
    {
        question: "What is the capital of France?",
        options: ["Paris", "Berlin", "Madrid", "Rome"],
        correct: "Paris",
      },
      {
        question: "Which country is known as the Land of the Rising Sun?",
        options: ["Australia", "China", "Japan", "India"],
        correct: "Japan",
      },
      {
        question: "Which river is the longest in the world?",
        options: ["Amazon", "Yangtze", "Mississippi", "Nile"],
        correct: "Nile",
      },
      {
        question: "What is the largest desert in the world?",
        options: ["Gobi", "Arabian", "Sahara", "Kalahari"],
        correct: "Sahara",
      },
      {
        question: "Which continent is the largest by land area?",
        options: ["Africa", "Europe", "Asia", "Antarctica"],
        correct: "Asia",
      },
      {
        question: "Mount Everest is located in which mountain range?",
        options: ["Rockies", "Andes", "Alps", "Himalayas"],
        correct: "Himalayas",
      },
      {
        question: "Which ocean is the largest in the world?",
        options: [
          "Atlantic Ocean",
          "Indian Ocean",
          "Arctic Ocean",
          "Pacific Ocean",
        ],
        correct: "Pacific Ocean",
      },
      {
        question: "What is the smallest country in the world by land area?",
        options: ["Monaco", "Nauru", "Vatican City", "San Marino"],
        correct: "Vatican City",
      },
      {
        question: "Which country has the most natural lakes?",
        options: [
          "United States",
          "Finland",
          "Canada",
          "Russia",
        ],
        correct: "Canada",
      },
      {
        question: "The Great Barrier Reef is off the coast of which country?",
        options: ["Australia", "Indonesia", "Philippines", "Fiji"],
        correct: "Australia",
      },
      {
        question: "In which country can you visit Machu Picchu?",
        options: ["Brazil", "Peru", "Bolivia", "Chile"],
        correct: "Peru",
      },
      {
        question: "The river Danube flows into which sea?",
        options: ["North Sea", "Black Sea", "Baltic Sea", "Caspian Sea"],
        correct: "Black Sea",
      },
      {
        question: "Which city is known as the 'City of Canals'?",
        options: ["Amsterdam", "Bruges", "Venice", "Stockholm"],
        correct: "Venice",
      },
      {
        question: "What is the official language of Brazil?",
        options: ["Spanish", "English", "Portuguese", "French"],
        correct: "Portuguese",
      },
      {
        question: "The island of Sicily is part of which country?",
        options: ["Greece", "Spain", "Italy", "France"],
        correct: "Italy",
      },
      {
        question: "Which country is known as the birthplace of democracy?",
        options: ["Italy", "Greece", "Egypt", "India"],
        correct: "Greece",
      },
      {
        question: "The Pyramids of Giza are located in which country?",
        options: ["Jordan", "Saudi Arabia", "Egypt", "Sudan"],
        correct: "Egypt",
      },
      {
        question: "Which is the largest island in the Mediterranean Sea?",
        options: ["Corsica", "Sicily", "Crete", "Sardinia"],
        correct: "Sicily",
      },
      {
        question: "Which city is known as the 'Big Apple'?",
        options: [
          "Los Angeles",
          "Chicago",
          "New York City",
          "San Francisco",
        ],
        correct: "New York City",
      },
      {
        question: "The Taj Mahal is located in which Indian city?",
        options: ["New Delhi", "Mumbai", "Agra", "Jaipur"],
        correct: "Agra",
      },
  ];
  
  const quizContainer = document.querySelector(".quiz-container");
  const question = document.querySelector(".quiz-container .question");
  const options = document.querySelector(".quiz-container .options");
  const nextBtn = document.querySelector(".quiz-container .next-btn");
  const quizResult = document.querySelector(".quiz-result");
  const startBtnContainer = document.querySelector(".start-btn-container");
  const startBtn = document.querySelector(".start-btn-container .start-btn");
  
  let questionNumber = 0;
  let score = 0;
  const MAX_QUESTIONS = 5;
  let timerInterval;
  
  const shuffleArray = (array) => {
    return array.slice().sort(() => Math.random() - 0.5);
  };
  
  quizData = shuffleArray(quizData);
  
  const resetLocalStorage = () => {
    for (i = 0; i < MAX_QUESTIONS; i++) {
      localStorage.removeItem(`userAnswer_${i}`);
    }
  };
  
  resetLocalStorage();
  
  const checkAnswer = (e) => {
    let userAnswer = e.target.textContent;
    if (userAnswer === quizData[questionNumber].correct) {
      score++;
      e.target.classList.add("correct");
    } else {
      e.target.classList.add("incorrect");
    }
  
    localStorage.setItem(`userAnswer_${questionNumber}`, userAnswer);
  
    let allOptions = document.querySelectorAll(".quiz-container .option");
    allOptions.forEach((o) => {
      o.classList.add("disabled");
    });
  };
  
  const createQuestion = () => {
    clearInterval(timerInterval);
  
    let secondsLeft = 9;
    const timerDisplay = document.querySelector(".quiz-container .timer");
    timerDisplay.classList.remove("danger");
  
    timerDisplay.textContent = `Time Left: 10 seconds`;
  
    timerInterval = setInterval(() => {
      timerDisplay.textContent = `Time Left: ${secondsLeft
        .toString()
        .padStart(2, "0")} seconds`;
      secondsLeft--;
  
      if (secondsLeft < 3) {
        timerDisplay.classList.add("danger");
      }
  
      if (secondsLeft < 0) {
        clearInterval(timerInterval);
        displayNextQuestion();
      }
    }, 1000);
  
    options.innerHTML = "";
    question.innerHTML = `<span class='question-number'>${
      questionNumber + 1
    }/${MAX_QUESTIONS}</span>${quizData[questionNumber].question}`;
  
    const shuffledOptions = shuffleArray(quizData[questionNumber].options);
  
    shuffledOptions.forEach((o) => {
      const option = document.createElement("button");
      option.classList.add("option");
      option.innerHTML = o;
      option.addEventListener("click", (e) => {
        checkAnswer(e);
      });
      options.appendChild(option);
    });
  };
  
  const retakeQuiz = () => {
    questionNumber = 0;
    score = 0;
    quizData = shuffleArray(quizData);
    resetLocalStorage();
  
    createQuestion();
    quizResult.style.display = "none";
    quizContainer.style.display = "block";
  };
  
  const displayQuizResult = () => {
    quizResult.style.display = "flex";
    quizContainer.style.display = "none";
    quizResult.innerHTML = "";
  
    const resultHeading = document.createElement("h2");
    resultHeading.innerHTML = `You have scored ${score} out of ${MAX_QUESTIONS}.`;
    quizResult.appendChild(resultHeading);
  
    for (let i = 0; i < MAX_QUESTIONS; i++) {
      const resultItem = document.createElement("div");
      resultItem.classList.add("question-container");
  
      const userAnswer = localStorage.getItem(`userAnswer_${i}`);
      const correctAnswer = quizData[i].correct;
  
      let answeredCorrectly = userAnswer === correctAnswer;
  
      if (!answeredCorrectly) {
        resultItem.classList.add("incorrect");
      }
  
      resultItem.innerHTML = `<div class="question">Question ${i + 1}: ${
        quizData[i].question
      }</div>
      <div class="user-answer">Your answer: ${userAnswer || "Not Answered"}</div>
      <div class="correct-answer">Correct answer: ${correctAnswer}</div>`;
  
      quizResult.appendChild(resultItem);
    }
  
    const retakeBtn = document.createElement("button");
    retakeBtn.classList.add("retake-btn");
    retakeBtn.innerHTML = "Retake Quiz";
    retakeBtn.addEventListener("click", retakeQuiz);
    quizResult.appendChild(retakeBtn);
  };
  
  const displayNextQuestion = () => {
    if (questionNumber >= MAX_QUESTIONS - 1) {
      displayQuizResult();
      return;
    }
  
    questionNumber++;
    createQuestion();
  };
  
  nextBtn.addEventListener("click", displayNextQuestion);
  
  startBtn.addEventListener("click", () => {
    startBtnContainer.style.display = "none";
    quizContainer.style.display = "block";
    createQuestion();
  });